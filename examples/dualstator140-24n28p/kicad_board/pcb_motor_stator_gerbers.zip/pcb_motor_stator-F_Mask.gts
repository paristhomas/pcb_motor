%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-07-09T00:40:56+01:00*%
%TF.ProjectId,pcb_motor_stator,7063625f-6d6f-4746-9f72-5f737461746f,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-07-09 00:40:56*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
