%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-07-03T19:28:12+01:00*%
%TF.ProjectId,gimbal90_routed_tabs,67696d62-616c-4393-905f-726f75746564,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-07-03 19:28:12*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.100000*%
G04 APERTURE END LIST*
D10*
%TO.C,M1*%
X185149000Y-61041000D03*
X181359000Y-57251000D03*
X177195000Y-53878000D03*
X191441000Y-69700000D03*
X188522000Y-65205000D03*
X193874000Y-74475000D03*
%TD*%
M02*
